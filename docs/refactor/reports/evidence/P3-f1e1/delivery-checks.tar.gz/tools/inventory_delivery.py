"""Record the exact proposed commit set without staging anything."""

import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/Users/lld/emtl')
DEST = ROOT / 'docs/refactor/reports/evidence/P3-f1e1/delivery-inventory.json'


def main():
    tracked = subprocess.check_output(['git', 'diff', '--name-only', '-z'], cwd=ROOT).decode().split('\0')[:-1]
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=ROOT).decode().split('\0')[:-1]
    assert not subprocess.check_output(['git', 'diff', '--cached'], cwd=ROOT)
    relative = DEST.relative_to(ROOT).as_posix()
    paths = sorted(set(tracked + untracked + [relative]))
    files = []
    for name in paths:
        assert not name.startswith(('dist/', '.venv/', '.tox/')) and '__pycache__' not in Path(name).parts
        files.append(dict(path=name, state='modified tracked' if name in tracked else 'untracked new',
                          sha256=None if name == relative else hashlib.sha256((ROOT / name).read_bytes()).hexdigest()))
    payload = dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
                   branch=subprocess.check_output(['git', 'branch', '--show-current'], cwd=ROOT).decode().strip(),
                   staged_empty=True, proposed_count=len(paths), files=files,
                   self_hash='null only for this inventory to avoid self-reference; all other proposed files hashed',
                   scope='Exact proposed commit set includes approved preexisting P3 implementation; F1/E1 did not alter production/tests/CI/config. No staging/commit/push performed.')
    DEST.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + '\n')
    print('Proposed files:', len(paths), '; tracked modified:', len(tracked), '; new:', len(paths) - len(tracked))


if __name__ == '__main__':
    main()
