"""One-off quality gate for the complete proposed P3 delivery tree."""

import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path('/Users/lld/emtl')
OUT = ROOT / 'dist/p3-f1e1/f1'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main(label):
    output = OUT / label
    output.mkdir(parents=True, exist_ok=False)
    records = []

    def run(args, cwd=ROOT, env=None, timeout=600):
        result = subprocess.run(args, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
        log = f'command-{len(records):02d}.log'
        (output / log).write_bytes(result.stdout)
        records.append(dict(args=[str(a) for a in args], cwd=str(cwd), exit_code=result.returncode, log=log))
        (output / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
        return result

    def git(*args):
        result = run(['git', *args])
        assert result.returncode == 0
        return result.stdout.decode()

    protected = json.loads((ROOT / 'dist/p3-r3/source-sha256.json').read_text())
    assert all(sha(ROOT / p) == h for p, h in protected.items())
    index = Path(git('rev-parse', '--git-path', 'index').strip())
    index = index if index.is_absolute() else ROOT / index
    index_hash = sha(index)
    tracked = git('ls-files', '-z').split('\0')[:-1]
    untracked = git('ls-files', '--others', '--exclude-standard', '-z').split('\0')[:-1]
    candidates = sorted(set(tracked + untracked))
    manifest = {p: sha(ROOT / p) for p in candidates}
    (output / 'candidate-files.json').write_text(json.dumps(candidates, indent=2) + '\n')
    (output / 'candidate-sha256.json').write_text(json.dumps(manifest, indent=2) + '\n')
    snapshot = output / 'candidate-tree'
    snapshot.mkdir()
    for name in candidates:
        source, target = ROOT / name, snapshot / name
        assert not source.is_symlink(), name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    assert run(['git', 'init', '--quiet'], cwd=snapshot).returncode == 0
    assert run(['git', 'add', '--force', '--', *candidates], cwd=snapshot).returncode == 0
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    for key in list(env):
        if key.startswith('EM_') or key in {'NETRC', 'SSH_AUTH_SOCK', 'SSH_AGENT_PID', 'PIP_INDEX_URL', 'PIP_EXTRA_INDEX_URL'}:
            env.pop(key)
    precommit = shutil.which('pre-commit')
    assert precommit
    result = run([precommit, 'run', '--all-files'], cwd=snapshot, env=env)
    changed = [p for p, h in manifest.items() if sha(snapshot / p) != h]
    (output / 'snapshot-hook-changes.json').write_text(json.dumps(changed, indent=2) + '\n')
    if result.returncode or changed:
        raise SystemExit('Candidate pre-commit failed; originals untouched; see ' + str(output))
    changed_paths = git('diff', '--name-only', '-z').split('\0')[:-1]
    python = sorted(p for p in set(changed_paths + untracked) if p.endswith('.py'))
    assert python
    assert run([str(ROOT / '.venv/bin/ruff'), 'check', '--no-cache', *python], env=env).returncode == 0
    assert run([str(ROOT / '.venv/bin/black'), '--check', *python], env=env).returncode == 0
    assert run([precommit, 'run', '--all-files'], env=env).returncode == 0
    assert run(['git', 'diff', '--check']).returncode == 0
    assert run(['git', 'diff', '--cached', '--check']).returncode == 0
    assert all(sha(ROOT / p) == h for p, h in manifest.items())
    assert sha(index) == index_hash
    result = dict(status='PASS', candidate_count=len(candidates), changed_python=python,
                  all_untracked_in_isolated_all_files=True, real_worktree_all_files=True,
                  real_index_unchanged=True, worktree_bytes_unchanged=True,
                  precommit_config_sha256=sha(ROOT / '.pre-commit-config.yaml'))
    (output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main(sys.argv[1])
