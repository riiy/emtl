"""Archive actual F1/E1 originals without rewriting their bytes."""

import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

ROOT = Path('/Users/lld/emtl')
BASE = ROOT / 'dist/p3-f1e1'
DEST = ROOT / 'docs/refactor/reports/evidence/P3-f1e1'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    assert json.loads((BASE / 'e1/verification-summary.json').read_text())['status'] == 'PASS'
    contents = {}
    for directory in ('e1', 'f1'):
        for path in sorted((BASE / directory).rglob('*')):
            if not path.is_file() or 'candidate-tree' in path.parts or '__pycache__' in path.parts:
                continue
            contents[path.relative_to(BASE).as_posix()] = path.read_bytes()
    for path in sorted((BASE / 'tools').glob('*.py')):
        contents['tools/' + path.name] = path.read_bytes()
    for path in sorted((BASE / 'tools/original').glob('*.py')):
        contents['tools/original/' + path.name] = path.read_bytes()
    DEST.mkdir(exist_ok=True)
    archive = DEST / 'raw-evidence.tar.gz'
    assert not archive.exists(), 'do not replace prior raw evidence archive'
    with archive.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as tar:
                for name, data in sorted(contents.items()):
                    info = tarfile.TarInfo(name)
                    info.size, info.mode, info.mtime = len(data), 0o644, 0
                    tar.addfile(info, io.BytesIO(data))
    manifest = {name: sha(data) for name, data in sorted(contents.items())}
    with tarfile.open(archive, 'r:gz') as tar:
        actual = {m.name: sha(tar.extractfile(m).read()) for m in tar.getmembers()}
    assert actual == manifest
    (DEST / 'raw-files-sha256.json').write_text(json.dumps(dict(
        archive=archive.name, archive_sha256=sha(archive.read_bytes()), files=manifest,
        exclusions='isolated candidate-tree copies/.git are reconstructible from recorded manifests; no original command logs excluded',
    ), indent=2) + '\n')
    (DEST / 'SHA256SUMS').write_text(''.join(f'{sha((DEST / name).read_bytes())}  {name}\n'
                                          for name in ('raw-evidence.tar.gz', 'raw-files-sha256.json')))
    print('Archived and verified', len(manifest), 'original evidence files')


if __name__ == '__main__':
    main()
