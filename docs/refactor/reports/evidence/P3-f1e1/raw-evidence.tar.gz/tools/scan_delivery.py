"""One-off recursive static credential-pattern scan; never prints matched values."""

import hashlib
import io
import json
import re
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/Users/lld/emtl')
RULES = {
    'private_key': re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'),
    'credential_url': re.compile(rb'https?://[^\s/@:\"\x27]+:[^\s/@\"\x27]+@'),
    'github_token': re.compile(rb'\bgh[pousr]_[A-Za-z0-9]{30,}\b'),
    'aws_access_id': re.compile(rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b'),
}


def main(output):
    names = sorted(set(subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')[:-1]
                       + subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=ROOT).decode().split('\0')[:-1]))
    findings, archive_members = [], []

    def scan(name, data, depth=0):
        for rule, pattern in RULES.items():
            if pattern.search(data):
                findings.append(dict(file=name, kind=rule))
        if name.endswith('.tar.gz'):
            assert depth < 5
            with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
                for member in archive.getmembers():
                    assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
                    qualified = name + '!' + member.name
                    archive_members.append(qualified)
                    scan(qualified, archive.extractfile(member).read(), depth + 1)

    for name in names:
        path = ROOT / name
        if path.name.lower() in {'.env', '.netrc', 'id_rsa', 'id_ed25519'} or path.suffix.lower() in {'.p12', '.pfx'}:
            findings.append(dict(file=name, kind='credential_file_name'))
        scan(name, path.read_bytes())
    result = dict(status='PASS' if not findings else 'FAIL', files=len(names), archive_members=len(archive_members),
                  rules=list(RULES), findings=findings, real_account_environment_read=False,
                  limitation='Static patterns are not exhaustive. Credential-like code literals separately reviewed as synthetic test sentinels.')
    Path(output).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    assert not findings


if __name__ == '__main__':
    import sys
    main(sys.argv[1])
