"""Reproducible host evidence collection; never changes production/tests/CI."""

import hashlib
import json
import os
import shutil
import subprocess
import sys
import traceback
import uuid
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
sys.path.insert(0, str(HERE))
from observe import junit


def dump(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def load(name):
    return json.loads((HERE / name).read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(args, label, *, check=True):
    start = datetime.now(timezone.utc).isoformat()
    log = HERE / f'{label}.log'
    with log.open('w') as stream:
        result = subprocess.run(args, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=False)
    records = load('host-commands.json') if (HERE / 'host-commands.json').exists() else []
    records.append(dict(args=[str(a) for a in args], cwd=str(ROOT), exit_code=result.returncode,
                        start=start, end=datetime.now(timezone.utc).isoformat(), log=log.name))
    dump('host-commands.json', records)
    print(f'{label}: exit {result.returncode}', flush=True)
    if check and result.returncode:
        raise RuntimeError(f'{label} failed: {result.returncode}; see {log}')
    return result.returncode, log.read_text()


def git(args, label):
    return command(['git', *args], label)[1]


def prepare():
    assert ROOT == Path('/Users/lld/emtl'), ROOT
    assert not (HERE / 'run.json').exists(), 'do not overwrite an earlier run'
    run_id = uuid.uuid4().hex[:12]
    dump('run.json', dict(tag=f'emtl-p3-final-linux:{run_id}', container=f'emtl-p3-final-{run_id}',
                         timestamp=datetime.now(timezone.utc).isoformat()))
    head = git(['rev-parse', 'HEAD'], 'git-head').strip()
    branch = git(['branch', '--show-current'], 'git-branch').strip()
    status = git(['status', '--short', '--untracked-files=all'], 'git-status-before')
    git(['diff', '--binary', '--no-ext-diff'], 'git-diff-before')
    staged = git(['diff', '--cached', '--binary', '--no-ext-diff'], 'git-staged-before')
    tracked = git(['ls-files'], 'git-tracked-before').splitlines()
    untracked = git(['ls-files', '--others', '--exclude-standard'], 'git-untracked-before').splitlines()
    original = {name: sha(ROOT / name) for name in sorted(set(tracked + untracked))
                if not name.startswith(str(HERE.relative_to(ROOT)) + '/')}
    dump('original-workspace-sha256.json', original)
    dump('workspace-before.json', dict(head=head, branch=branch, dirty=bool(status), status=status,
                                     staged_dirty=bool(staged), tracked=tracked, untracked=untracked))
    old = json.loads((ROOT / 'dist/p3-r3/source-sha256.json').read_text())
    assert all(sha(ROOT / name) == digest for name, digest in old.items()), 'R3 source snapshot drift'
    dump('source-sha256.json', old)
    for name in ('final-pytest-junit.xml', 'final-tox-junit.xml', 'source-sha256.json'):
        shutil.copyfile(ROOT / 'dist/p3-r3' / name, HERE / f'baseline-{name}')
    nodes = junit(HERE / 'baseline-final-pytest-junit.xml')['nodes']
    assert junit(HERE / 'baseline-final-tox-junit.xml')['nodes'] == nodes
    dump('expected-nodes.json', nodes)
    # Mirror the original Dockerfile COPY inputs, not git archive: includes untracked fixtures and docs.
    roots = ['src', 'tests', 'ci', 'docs', '.github/workflows']
    names = set(['setup.py', 'pyproject.toml', 'README.rst', 'CHANGELOG.rst', 'LICENSE',
                 'tox.ini', 'pytest.ini', '.coveragerc', '.dockerignore', 'conftest.py'])
    excluded = []
    for root in roots:
        for path in (ROOT / root).rglob('*'):
            if not path.is_file():
                continue
            name = path.relative_to(ROOT).as_posix()
            if path.is_relative_to(HERE):
                continue  # self-producing evidence is not source input; Docker still includes it
            if ('__pycache__' in path.parts or path.suffix == '.pyc'
                    or (path.name == '_version.py' and name.startswith('src/'))):
                excluded.append(name)
                continue
            assert not path.is_symlink(), f'input symlink requires review: {name}'
            names.add(name)
    inputs = {name: sha(ROOT / name) for name in sorted(names)}
    dump('copy-inputs-sha256.json', inputs)
    dump('source-tests-sha256.json', {n: h for n, h in inputs.items()
                                    if n.startswith(('src/', 'tests/')) or n == 'conftest.py'})
    assert {'src/emtl/errors.py', 'tests/test_trade_errors.py', 'tests/fixtures/protocol_cases.json'} <= names
    dump('build-context-audit.json', dict(context='.', dockerfile='ci/offline.Dockerfile',
         no_cache=True, git_archive=False, input_count=len(inputs), excluded_generated=excluded,
         dockerignore=(ROOT / '.dockerignore').read_text(),
         untracked_required=[n for n in untracked if n in inputs],
         evidence_self_exclusion='P3-final-linux evidence is COPYed but excluded from self-referential input manifest; all other COPY inputs checked inside image before/after tests'))
    command(['docker', 'version'], 'docker-version')
    print(f'Prepared {len(inputs)} COPY inputs; current baseline has {len(nodes)} nodes', flush=True)


def build():
    run = load('run.json')
    command(['docker', 'build', '--no-cache', '--file', 'ci/offline.Dockerfile',
             '--tag', run['tag'], '--iidfile', str(HERE / 'image-id.txt'), '.'], 'docker-build-final')
    image_id = (HERE / 'image-id.txt').read_text().strip()
    _, text = command(['docker', 'image', 'inspect', image_id], 'image-inspect')
    image = json.loads(text)[0]
    assert image['Id'] == image_id and image['Os'] == 'linux'
    dump('image-identity.json', dict(id=image_id, repo_digests=image.get('RepoDigests', []),
                                   platform=f"{image['Os']}/{image['Architecture']}", created=image['Created'],
                                   tag=run['tag'], no_cache=True))


def execute_tests():
    run = load('run.json')
    image_id = load('image-identity.json')['id']
    name = run['container']
    statuses = {}
    created = False
    primary = None
    try:
        command(['docker', 'create', '--name', name, '--network', 'none', image_id,
                 'python', str(Path('/workspace') / HERE.relative_to(ROOT) / 'observe.py')], 'container-create')
        created = True
        _, text = command(['docker', 'inspect', name], 'container-inspect-before')
        info = json.loads(text)[0]
        assert info['HostConfig']['NetworkMode'] == 'none'
        assert info['Image'] == image_id and not info['Mounts']
        (HERE / 'network-mode.txt').write_text('NetworkMode=none\n')
        dump('network-mode.json', dict(NetworkMode=info['HostConfig']['NetworkMode'], image=info['Image'],
                                       mounts=info['Mounts'], container=name))
        statuses['start'], _ = command(['docker', 'start', '--attach', name], 'container-full', check=False)
        if statuses['start']:
            raise RuntimeError(f"container exited nonzero: {statuses['start']}")
    except BaseException as error:
        primary = error
    finally:
        if created:
            statuses['logs'], _ = command(['docker', 'logs', name], 'container-logs', check=False)
            statuses['inspect'], text = command(['docker', 'inspect', name], 'container-inspect-after', check=False)
            if not statuses['inspect']:
                info = json.loads(text)[0]
                dump('container-state.json', info['State'])
                statuses['container_exit_code'] = info['State']['ExitCode']
                statuses['running'] = info['State']['Running']
                statuses['network_mode_after'] = info['HostConfig']['NetworkMode']
            (HERE / 'reports').mkdir(exist_ok=True)
            statuses['copy'], _ = command(['docker', 'cp', f'{name}:/workspace/dist/p1-offline/.', str(HERE / 'reports')],
                                           'reports-copy', check=False)
            # Only our uniquely named container, after evidence collection; no forced deletion of others.
            statuses['cleanup'], _ = command(['docker', 'rm', name], 'container-cleanup', check=False)
            _, text = command(['docker', 'ps', '--all', '--quiet', '--filter', f'name=^/{name}$'], 'cleanup-check')
            statuses['container_absent_after_cleanup'] = not text.strip()
        dump('host-status.json', statuses)
    if primary:
        raise primary
    assert all(statuses[k] == 0 for k in ('start', 'logs', 'inspect', 'container_exit_code', 'copy', 'cleanup')), statuses
    assert statuses['container_absent_after_cleanup'] and not statuses['running']
    assert statuses['network_mode_after'] == 'none'


def verify():
    report = HERE / 'reports'
    summaries = {name: junit(report / name) for name in ('junit.xml', 'outside-junit.xml', 'explicit-junit.xml')}
    expected = load('expected-nodes.json')
    assert all([list(node) for node in summary['nodes']] == expected for summary in summaries.values())
    for item in summaries.values():
        item.pop('nodes')
    commands = json.loads((report / 'commands.json').read_text())
    assert all(item['exit_code'] == 0 for item in commands)
    probes = [item for item in commands if item['args'][-1] == 'ci/check_offline_network.py']
    assert len(probes) == 7
    assert all('OS network namespace isolation verified' in (report / item['log']).read_text() for item in probes)
    entries = json.loads((report / 'per-entry-verification.json').read_text())
    assert len(entries) == 3
    tox_entry = commands[entries[0]['command_index']]
    tox_log = (report / tox_entry['log']).read_text()
    assert tox_log.index('account environment isolated') < tox_log.index('test session starts')
    tox_result = json.loads((report / 'tox-result.json').read_text())
    dump('tox-isolation-verification.json', dict(status='PASS', synthetic_parent=json.loads((report / 'synthetic-environment.json').read_text()),
         pre_pytest_check='account environment isolated', log=tox_entry['log'], tox_result_present=bool(tox_result)))
    coverage = json.loads((report / 'coverage.json').read_text())
    assert coverage['files'] and coverage['totals']['num_statements'] > 0
    for stage in ('before', 'after'):
        assert json.loads((report / f'image-inputs-{stage}.json').read_text()) == load('copy-inputs-sha256.json')
    assert json.loads((report / 'observer-status.json').read_text())['status'] == 'PASS'
    original = load('original-workspace-sha256.json')
    assert all(sha(ROOT / name) == digest for name, digest in original.items()), 'host input drift'
    head = git(['rev-parse', 'HEAD'], 'git-head-after').strip()
    assert head == load('workspace-before.json')['head']
    git(['status', '--short', '--untracked-files=all'], 'git-status-after-tests')
    command(['git', 'diff', '--check'], 'diff-check')
    command(['git', 'diff', '--cached', '--check'], 'staged-diff-check')
    dump('verification-summary.json', dict(status='PASS', head=head, dirty=True, image=load('image-identity.json'),
         junit=summaries, identical_467_nodes=True, failures=0, errors=0, skipped=0, probes=len(probes),
         per_entry_probes=True, tox_credential_isolation=True, coverage_totals=coverage['totals'],
         input_count=len(load('copy-inputs-sha256.json')), all_image_inputs_match=True,
         all_original_workspace_files_unchanged=True, versions=json.loads((report / 'versions.json').read_text()),
         host_status=load('host-status.json')))
    print(json.dumps(load('verification-summary.json'), indent=2), flush=True)


def seal():
    manifest = {p.relative_to(HERE).as_posix(): sha(p) for p in sorted(HERE.rglob('*'))
                if p.is_file() and p.name not in ('evidence-sha256.json', 'SHA256SUMS') and '__pycache__' not in p.parts}
    dump('evidence-sha256.json', manifest)
    (HERE / 'SHA256SUMS').write_text(''.join(f'{digest}  {name}\n' for name, digest in manifest.items()))
    assert all(sha(HERE / name) == digest for name, digest in manifest.items())
    print(f'Sealed and verified {len(manifest)} evidence files', flush=True)


if __name__ == '__main__':
    try:
        {'prepare': prepare, 'build': build, 'run': execute_tests, 'verify': verify, 'seal': seal}[sys.argv[1]]()
    except BaseException:
        (HERE / f'failure-{sys.argv[1]}.txt').write_text(traceback.format_exc())
        raise
