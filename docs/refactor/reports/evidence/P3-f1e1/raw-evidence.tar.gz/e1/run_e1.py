"""Single-use continuation of the original evidence-only host observer."""

import importlib.util
import json
import shutil
import sys
import traceback
from pathlib import Path

ROOT = Path('/Users/lld/emtl')
ORIGINAL = ROOT / 'dist/p3-f1e1/tools/original'
OUT = ROOT / 'dist/p3-f1e1/e1'
sys.path.insert(0, str(ORIGINAL))
spec = importlib.util.spec_from_file_location('original_host', ORIGINAL / 'verify_host.py')
host = importlib.util.module_from_spec(spec)
spec.loader.exec_module(host)
host.ROOT = ROOT
host.HERE = OUT


def prepare():
    OUT.mkdir(exist_ok=False)
    assert json.loads((ROOT / 'dist/p3-f1e1/f1/f1-preserve-modes/result.json').read_text())['status'] == 'PASS'
    host.prepare()
    attachments = OUT / 'attachments'
    attachments.mkdir()
    for name in ('expected-nodes.json', 'copy-inputs-sha256.json'):
        shutil.copy2(OUT / name, attachments / name)
    shutil.copy2(ORIGINAL / 'observe.py', attachments / 'observe.py')
    for source in (Path(__file__), ORIGINAL / 'verify_host.py'):
        shutil.copy2(source, OUT / source.name)
    host.dump('attachment-sha256.json', {p.name: host.sha(p) for p in attachments.iterdir()})
    host.dump('host-tools-sha256.json', {p.name: host.sha(p) for p in (OUT / 'run_e1.py', OUT / 'verify_host.py')})


def run_tests():
    run = host.load('run.json')
    image = host.load('image-identity.json')['id']
    name = run['container']
    statuses = {}
    created = False
    primary = None
    try:
        host.command(['docker', 'create', '--name', name, '--network', 'none', image,
                      'python', '/p3-evidence/observe.py'], 'container-create')
        created = True
        host.command(['docker', 'cp', str(OUT / 'attachments') + '/.', name + ':/p3-evidence'], 'attachments-copy')
        _, text = host.command(['docker', 'inspect', name], 'container-inspect-before')
        info = json.loads(text)[0]
        assert info['Image'] == image and info['HostConfig']['NetworkMode'] == 'none' and not info['Mounts']
        assert not any(value.split('=', 1)[0].startswith('EM_') for value in info['Config']['Env'])
        host.dump('network-mode.json', dict(NetworkMode='none', image=image, mounts=[], container=name))
        statuses['start'], _ = host.command(['docker', 'start', '--attach', name], 'container-full', check=False)
        assert statuses['start'] == 0, statuses
    except BaseException as error:
        primary = error
    finally:
        if created:
            statuses['logs'], _ = host.command(['docker', 'logs', name], 'container-logs', check=False)
            statuses['inspect'], text = host.command(['docker', 'inspect', name], 'container-inspect-after', check=False)
            if not statuses['inspect']:
                info = json.loads(text)[0]
                host.dump('container-state.json', info['State'])
                statuses.update(container_exit_code=info['State']['ExitCode'], running=info['State']['Running'],
                                network_mode_after=info['HostConfig']['NetworkMode'])
            (OUT / 'reports').mkdir(exist_ok=True)
            statuses['copy'], _ = host.command(['docker', 'cp', name + ':/workspace/dist/p1-offline/.',
                                                str(OUT / 'reports')], 'reports-copy', check=False)
            statuses['cleanup'], _ = host.command(['docker', 'rm', name], 'container-cleanup', check=False)
            _, text = host.command(['docker', 'ps', '--all', '--quiet', '--filter', f'name=^/{name}$'], 'cleanup-check')
            statuses['container_absent_after_cleanup'] = not text.strip()
        host.dump('host-status.json', statuses)
    if primary:
        raise primary
    assert all(statuses[k] == 0 for k in ('start', 'logs', 'inspect', 'container_exit_code', 'copy', 'cleanup'))
    assert statuses['container_absent_after_cleanup'] and not statuses['running']
    assert statuses['network_mode_after'] == 'none'


if __name__ == '__main__':
    stage = sys.argv[1]
    try:
        {'prepare': prepare, 'build': host.build, 'run': run_tests, 'verify': host.verify, 'seal': host.seal}[stage]()
    except BaseException:
        if OUT.exists():
            (OUT / f'failure-{stage}.txt').write_text(traceback.format_exc())
        raise
