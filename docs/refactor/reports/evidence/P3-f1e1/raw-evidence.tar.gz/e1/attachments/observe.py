"""Evidence-only observer of the unchanged approved Linux offline driver."""

import hashlib
import importlib.util
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace')


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def junit(path):
    tree = ET.parse(path).getroot()
    suites = list(tree.iter('testsuite'))
    cases = list(tree.iter('testcase'))
    counts = {key: sum(int(s.get(key, '0')) for s in suites)
              for key in ('tests', 'failures', 'errors', 'skipped')}
    nodes = sorted((case.get('classname'), case.get('name')) for case in cases)
    assert counts == dict(tests=467, failures=0, errors=0, skipped=0), counts
    assert len(cases) == 467 and len(set(nodes)) == 467
    assert not any(list(case.iter(tag)) for case in cases for tag in ('failure', 'error', 'skipped'))
    return dict(counts, nodes=nodes, time=sum(float(s.get('time', '0')) for s in suites))


def main():
    spec = importlib.util.spec_from_file_location('approved_offline_driver', ROOT / 'ci/run_offline_tests.py')
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    driver.OUT.mkdir(parents=True, exist_ok=True)
    expected = json.loads((HERE / 'expected-nodes.json').read_text())
    manifest = json.loads((HERE / 'copy-inputs-sha256.json').read_text())

    def check_inputs(stage):
        actual = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in manifest}
        dump(driver.OUT / f'image-inputs-{stage}.json', actual)
        assert actual == manifest, 'image COPY inputs differ from current workspace snapshot'

    check_inputs('before')
    original_run = driver.run
    entries = []

    def observed_run(args, *, cwd=driver.ROOT, env=None):
        report = next((str(arg).split('=', 1)[1] for arg in args if str(arg).startswith('--junitxml=')), None)
        if report is None:
            return original_run(args, cwd=cwd, env=env)
        # These are real subprocess probes outside pytest; the guard cannot fake them.
        before_index = len(driver.COMMANDS)
        original_run([sys.executable, 'ci/check_offline_network.py'])
        test_index = len(driver.COMMANDS)
        text = original_run(args, cwd=cwd, env=env)
        after_index = len(driver.COMMANDS)
        original_run([sys.executable, 'ci/check_offline_network.py'])
        result = junit(Path(report))
        assert [list(node) for node in result['nodes']] == expected, 'JUnit node set mismatch; stop immediately'
        result.update(report=report, command_index=test_index, probe_before_index=before_index,
                      probe_after_index=after_index, process_exit_code=0)
        entries.append(result)
        dump(driver.OUT / 'per-entry-verification.json', entries)
        if '-m' in args and 'tox' in args:
            assert 'account environment isolated' in text, 'tox pre-pytest isolation check absent'
            assert text.index('account environment isolated') < text.index('test session starts')
        return text

    driver.run = observed_run
    try:
        driver.main()
        assert len(entries) == 3
        check_inputs('after')
        dump(driver.OUT / 'observer-status.json', {'status': 'PASS', 'entries': 3})
    except BaseException as error:
        dump(driver.OUT / 'observer-status.json', {'status': 'FAIL', 'type': type(error).__name__})
        raise


if __name__ == '__main__':
    main()
